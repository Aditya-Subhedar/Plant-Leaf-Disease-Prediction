# evaluate.py
import os
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from sklearn.metrics import classification_report

data_dir = "C:/Aditya programmes/DE_Mini_Project_2/train"
model_dir = "C:/Aditya programmes/DE_Mini_Project_2/code/models"

plant_types = ['Corn', 'Peach', 'Pepper', 'Potato', 'Soybean', 'Tomato']

print("Available models:", os.listdir(model_dir))

datagen = ImageDataGenerator(rescale=1./255, validation_split=0.2)

def evaluate_plant_model(plant):
    print(f"\nEvaluating model for {plant}...")

    # Check if plant directory exists
    plant_dir = os.path.join(data_dir, plant)
    if not os.path.exists(plant_dir):
        print(f"No data found for {plant}, skipping...")
        return None

    plant_classes = [folder for folder in os.listdir(plant_dir) if os.path.isdir(os.path.join(plant_dir, folder))]
    print(f"Classes for {plant}: {plant_classes}")

    validation_generator = datagen.flow_from_directory(
        plant_dir,  # use plant_dir directly
        target_size=(150, 150),
        batch_size=32,
        class_mode='categorical',
        subset='validation',
        classes=plant_classes
    )

    if validation_generator.samples == 0:
        print(f"No validation images found for {plant}, skipping...")
        return None

    model_path = os.path.join(model_dir, f"{plant}_model.keras")
    if not os.path.exists(model_path):
        print(f"Model for {plant} not found, skipping...")
        return None

    model = load_model(model_path)

    y_pred = model.predict(validation_generator)
    y_true = validation_generator.classes
    report = classification_report(y_true, y_pred.argmax(axis=1), target_names=validation_generator.class_indices.keys())

    print(report)
    return report

for plant in plant_types:
    evaluate_plant_model(plant)
