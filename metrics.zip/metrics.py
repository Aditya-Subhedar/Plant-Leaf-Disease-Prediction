import os
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from sklearn.metrics import classification_report, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns

model_path = 'C:/Aditya programmes/DE_Mini_Project_2/model/plant_disease_classifier.h5'

model = load_model(model_path)
print("Model loaded successfully.")

validation_dir = 'C:/Aditya programmes/DE_Mini_Project_2/validation'

validation_datagen = ImageDataGenerator(rescale=1./255)


validation_generator = validation_datagen.flow_from_directory(
    validation_dir,
    target_size=(224, 224),  
    batch_size=32,
    class_mode='categorical',
    shuffle=False
)


y_pred_probs = model.predict(validation_generator, verbose=1)

y_true = validation_generator.classes

y_pred = np.argmax(y_pred_probs, axis=1)

print("Classification Report:")
print(classification_report(y_true, y_pred, target_names=validation_generator.class_indices.keys()))

c# Normalize the confusion matrix
normalized_conf_matrix = conf_matrix.astype('float') / conf_matrix.sum(axis=1)[:, np.newaxis]

# Plot the normalized confusion matrix
plt.figure(figsize=(10, 8))
sns.heatmap(
    normalized_conf_matrix, 
    annot=True, 
    fmt='.2f', 
    cmap='Blues', 
    xticklabels=validation_generator.class_indices.keys(), 
    yticklabels=validation_generator.class_indices.keys()
)
plt.xlabel('Predicted Labels')
plt.ylabel('True Labels')
plt.title('Normalized Confusion Matrix')
plt.show()


accuracy = np.sum(y_true == y_pred) / len(y_true)
print(f"Accuracy: {accuracy * 100:.2f}%")
