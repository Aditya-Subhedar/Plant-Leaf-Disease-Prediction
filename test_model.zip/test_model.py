import tensorflow as tf
from tensorflow.keras.preprocessing import image
import numpy as np

# Load the trained model
model_path = r'C:\Aditya programmes\DE_Mini_Project_2\model\plant_disease_classifier.h5'
model = tf.keras.models.load_model(model_path)

class_labels = [
    'Apple___Apple_scab', 'Apple___Black_rot', 'Apple___Cedar_apple_rust', 'Apple___healthy', #...
]

def predict_image(image_path):
    img = image.load_img(image_path, target_size=(224, 224))
    img_array = image.img_to_array(img) / 255.0
    img_array = np.expand_dims(img_array, axis=0)
    
    predictions = model.predict(img_array)
    predicted_class = np.argmax(predictions[0])
    disease_name = class_labels[predicted_class]
    confidence = predictions[0][predicted_class] * 100
    
    print(f"Predicted Class: {disease_name}, Confidence: {confidence:.2f}%")

sample_image_path = r'path_to_your_sample_image.jpg'
predict_image(sample_image_path)
